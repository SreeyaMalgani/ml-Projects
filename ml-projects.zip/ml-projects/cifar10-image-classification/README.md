# CIFAR-10 Image Classification (PyTorch)

A comparative deep learning study on the CIFAR-10 dataset (10 classes, 32×32 RGB images), building from a simple linear model up to transfer learning and adversarial robustness.

## What I built
A clean, reusable **train / validation / test pipeline** (with per-epoch accuracy/loss logging), then a ladder of models:
1. **Linear classifier** (logistic regression) — baseline.
2. **MLP** — fully-connected network with a hidden layer.
3. **Custom CNN** — multi-block convolutional network (Conv → BatchNorm → ReLU → MaxPool) targeting ≥70% validation accuracy.
4. **Tuned CNN** — hyperparameter tuning with **data augmentation** (random crop/flip/rotation/color jitter), SGD + Nesterov momentum, weight decay, and a MultiStep LR scheduler.
5. **Transfer learning — AlexNet feature extractor** — froze pretrained backbone, retrained the final classifier layer.
6. **Transfer learning — AlexNet fine-tuning** — unfroze and fine-tuned the full network.
7. **Adversarial attacks (FGSM)** — implemented the Fast Gradient Sign Method to probe model robustness to small, imperceptible perturbations.

## Tech stack
Python, PyTorch, torchvision, NumPy, Matplotlib, Seaborn. Trained on Google Colab GPU.

## How to run
1. Open `cifar10_classification.ipynb` in Google Colab.
2. Set runtime to GPU.
3. Runtime → Run all (CIFAR-10 downloads automatically via torchvision).

## Contributions
Completed as part of a 3-person graduate team. *(Edit this line to reflect your specific contributions — e.g., "Implemented the custom CNN and transfer-learning experiments.")*
