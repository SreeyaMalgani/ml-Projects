# Machine Learning & Deep Learning Projects

**Sreeya Malgani** — M.S. Data Science, University at Albany (SUNY)

📌 Portfolio: https://sreeyamalgani.github.io/ • 💼 LinkedIn: https://www.linkedin.com/in/malgani-sreeya/

A collection of graduate-level machine learning and deep learning projects spanning classical ML, computer vision, and transformer research.

| Project | Area | Key Tech |
|---|---|---|
| [House Price Prediction](./house-price-prediction) | Classical ML / Regression | Python, AutoGluon, pandas, scikit-learn |
| [AirBnB Price Prediction](./airbnb-price-prediction) | Classical ML / Regression | Python, scikit-learn, Gradient Boosting, ensembling |
| [CIFAR-10 Image Classification](./cifar10-image-classification) | Deep Learning / Computer Vision | PyTorch, CNNs, Transfer Learning, FGSM |
| [Transformer Grokking](./transformer-grokking) | Deep Learning / Transformers | PyTorch, GPT-style Transformer |

### Skills demonstrated
Exploratory data analysis, feature engineering, model selection & ensembling, deep learning (CNNs, transfer learning, transformers), adversarial robustness, statistical analysis, experiment design, and clear technical communication.

---
*Some projects were completed as part of small graduate teams; contributions are noted within each project's README.*
