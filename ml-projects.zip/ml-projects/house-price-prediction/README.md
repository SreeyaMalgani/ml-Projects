# California House Price Prediction

End-to-end machine learning pipeline that predicts residential sale prices from a large California housing dataset.

## Overview
The project moves from raw data to a tuned, production-style regression model, with a strong emphasis on **avoiding data leakage** and **validating honestly**.

## What I built
- **Exploratory data analysis** — schema/null audits, target-distribution analysis (raw vs. log-transformed sale price), temporal price/volume trends, feature–target correlations, and price segmentation by property type.
- **Feature engineering** — cleaned and parsed messy fields (e.g., dollar strings), engineered temporal and categorical features, and processed each data split independently.
- **Leakage-aware validation** — a **time-aware train/validation/test split** with an explicit leakage audit (e.g., dropping historical sale price), since a random split would leak the upward price trend.
- **Experiments / ablations** — four controlled configurations isolating the impact of features, training window, and model preset.
- **Final model** — an **AutoGluon** stacked & bagged ensemble (LightGBM, XGBoost, CatBoost, Random Forest, Extra Trees, PyTorch NN) with a weighted ensemble, evaluated on **RMSE of log-price**.

## Tech stack
Python, AutoGluon, pandas, NumPy, Matplotlib.

## How to run
1. Open `house_price_prediction.ipynb` in Google Colab (or Jupyter).
2. Ensure the dataset (`house_sales.ftr`) is available as described in the notebook.
3. Runtime → Run all.
