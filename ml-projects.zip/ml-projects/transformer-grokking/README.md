# Transformer Grokking

A from-scratch study of **"grokking"** — the phenomenon where a neural network suddenly generalizes long after it has memorized the training data — using a small GPT-style transformer on modular-arithmetic tasks.

## What I built
- **GPT-style transformer from scratch** (PyTorch) — small decoder-only model with token-per-element encoding of arithmetic sequences `[a, op, b, =, c]`, computing loss only on the answer token.
- **Data generation** — addition, subtraction, and division modulo a prime (97, 113); division implemented via Fermat's little theorem. A 50% train/test split (the semi-interpolating regime required for grokking).
- **Sanity & masking checks** — verified the model could perfectly memorize a target string and that loss-masking infrastructure behaved correctly (loss decaying to ~10⁻⁴).
- **Experiment grid** — 24 runs across 3 seeds × 2 primes × 2 layer configs × 2 tasks (30k steps each), reporting mean ± std test accuracy and analyzing seed/architecture sensitivity.
- **Grokking experiment (division)** — a 100k-step run (1-layer, n_embd=128, 4 heads, AdamW, weight decay) tracking the train-vs-test accuracy gap to characterize when generalization occurs.

## Tech stack
Python, PyTorch (Flash Attention), NumPy, Matplotlib. Trained on Google Colab T4 GPU. Reproducible with fixed seeds.

## Contents
- `Project5_Grokking_Report.docx` — full write-up (setup, experiments, results, analysis).
- `Project5_Grokking.ipynb` — training & inference notebook (GPT-style transformer, sanity checks, experiment grid, grokking run).

## Contributions
Completed as part of a 3-person graduate team. *(Edit to reflect your specific contributions — e.g., "Built the data-generation pipeline and ran the division grokking experiments.")*
