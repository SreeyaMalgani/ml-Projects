# AirBnB Price Prediction

A Kaggle-style regression project that predicts AirBnB listing prices from mixed-type features (numeric, categorical, boolean, and text embeddings), starting from a Ridge baseline and progressively improving it.

## What I built
Starting from a provided Ridge baseline, I built an **enhanced solution to beat the baseline**:
- **EDA** — feature-vs-price relationships across room type and other listing attributes.
- **Feature engineering** — one-hot encoding of categoricals (fit on train only to avoid leakage), missing-value indicators, standardization, and use of precomputed **text embeddings**.
- **Modeling experiments**:
  1. Ridge baseline (starter) — evaluated with **RMSLE**.
  2. Ridge with enhanced features.
  3. **Gradient Boosting Regressor** (on raw price).
  4. GBR **hyperparameter search** + feature-importance analysis.
  5. **Random Forest**.
  6. **Ensemble blending** (GBR + Ridge + RF).
- **Validation** — a leakage-safe train/validation split plus **5-fold cross-validation** and an **ablation study** measuring each feature block's contribution.

## Tech stack
Python, scikit-learn (Ridge, GradientBoosting, RandomForest), pandas, NumPy, Matplotlib, Seaborn.

## How to run
1. Open `airbnb_price_prediction.ipynb` in Colab/Jupyter.
2. Provide `train.csv` / `test.csv` (and the embeddings file) as described in the config cell.
3. Runtime → Run all. Predictions are written to a submission file.

## Metric
Root Mean Squared Log Error (RMSLE).
